CREATE DATABASE SWALLOWTAILCLINIC;

CREATE TABLE AD_DRESS(
Ad_ID int identity (10,1) primary key,
Ad_L1 varchar (100) not null,
Ad_L2 varchar (100),
Ad_Ct varchar (100) not null,
Ad_Coun varchar (100) not null
);

INSERT INTO AD_DRESS (Ad_L1, Ad_L2, Ad_Ct, Ad_Coun)
values 
('90 Gt George St','','Savanna-la-mar','Jamaica'),
('7 Haining Road','Kingston 5','Kingston','Jamaica'),
('7 Kew Rd','Kingston 10','Kingston','Jamaica'),
('73 Harbour Street',' ','Kingston','Jamaica'),
('Central Village','Spanish Town','Spanish Town','Jamaica'),
('11 Queen St ','Kingston 1','Kingston ','Jamaica'),
('35 1/2 Hagley Pk Rd','Kingston 10','Kingston','Jamaica'),
(' Suite 15 27 Mannings Hill Rd','Kingston 8','Kingston ','Jamaica'),
(' Suite 4 27 Mannings Hill Rd','Kingston 8','Kingston ','Jamaica'),
(' Suite 3 27 Mannings Hill Rd','Kingston 8','Kingston ','Jamaica'),

(' 3 Musgrave Ave ','Kingston 5','Kingston ','Jamaica'),
('1 Chisholm Ave','Kingston 13','Kingston ','Jamaica');

select *from AD_DRESS

Patient
CREATE TABLE PAT(
Pat_ID tinyint identity (10,1) primary key,
Pat_Fname varchar(30) not null,
Pat_Lname varchar(30) not null,
Pat_Add int foreign key references AD_DRESS(Ad_ID)not null,
Pat_tele int,
Pat_email varchar(100),
Pat_Occ varchar(100),
Pat_MedDetails varchar(100),
);

INSERT INTO PAT(Pat_Fname,Pat_Lname,Pat_Add,Pat_tele,Pat_email,Pat_Occ,Pat_MedDetails)
values

('Tattianna ','Garvey','10',9669056,'T.Gatvey@yahoo.com','Teacher','Allergies'),
('Wyatt ','Carvick ','11',7699876,'WyatCarvick23@gmail.com','Laywer','Diabetes'),
('Darren  ','Hamilton','12',5938684,'DarrenHamil@gmail.com','Student','Seizures'),
('Wayne ','Ellison','13',9853729,'WayneEllison@hotmail.com','Welder','Cancer/Tumor'),
('Akeem ','Shaw','14',9194954,'AkeemShaw@hotmail.com','Student','Previous Surgeries'),
('Alice','Mcgowan','15',9753966,'A.Mcgowan@yahoo.com','Teacher','Hepatitis(A,B,C)'),
('Abdirahman ','Waters','16',7699876,'AbdWaters@hotmail.com','Student','Heart Disease'),
('Alyce  ','Cobb','17',8063346,'A.Cobb@gmail.com','HairDresser','Allergies'),
('Delano','Gobly','18',7804437,'DeloanoGob@gmail.com','Mechanic','High Blood Pressure'),
('Kason  ','Pemberton','19',8894600,'KasonPember@hotmail.com','Student','Kidney Problems');

SELECT Pat_Fname,Pat_Lname,Ad_L1,Ad_L2,Ad_Ct,Ad_Coun,Pat_tele,Pat_email,Pat_Occ,Pat_MedDetails
From PAT
INNER JOIN AD_DRESS on AD_DRESS.Ad_ID = PAT.Pat_ID; 

-Doctor----

CREATE TABLE Doctor(
Doc_ID tinyint identity (1,2) primary key,
Doc_Fname varchar(30) not null,
Doc_Lname varchar(30) not null,
Doc_Special varchar(30) not null,
);
SELECT * FROM Doctor
insert into Doctor ( Doc_Fname ,Doc_Lname,Doc_Special)
values

 ('Brent' ,'Weeks','Respiratory'),
 ('Ursula' ,'Guin','Respiratory'),
 
 ('Sarah' ,'Gailey','Cardio'),
 ( 'Neal' ,'Stephenson','Cardio'),

 ( 'Tia' ,'Williams','General'),
 ( 'Kate' ,'Clayborn','General' ),

( 'Joan' ,'Samson','Pediatric'),
( 'Alma' ,'Katsu', 'Pediatric'  );

--Prescription-----------
CREATE TABLE Prescription(
Pr_ID tinyint identity (1,2) primary key,
App_ID tinyint foreign key references Doctor(Doc_ID),
Med_Name varchar(100) not null,
);

INSERT INTO PRESCRIPTION (Pr_ID, App_ID,Med_Name)
VALUES
('12','32','Hydrocotisone'),
('3','5','Antibiotics'),

('12','14','Isotretinoin'),
('13','41','Antihisamines'),

('24','21','Pain Killers'),
('9','2','Metformin'),

('92','21','Lisinopril'),
('45','54','Aspirin'),

('64','10','Nasal Spray'),
('52','46','Iron Supplements');

SELECT Pr_ID,App_ID,Med_Name
FROM Prescription
INNER JOIN Doctor on Doctor.Doc_ID = Prescription.Pr_ID;

--Appointment--------

CREATE TABLE Appointment(
App_ID int identity (1050,1) primary key,
Pat_ID int not null,
Doc_ID tinyint foreign key references Doctor(Doc_ID) not null,
App_Date date not null,
App_Date_Returned date,
);

DROP TABLE Appointment

INSERT INTO Appointment (App_ID,Pat_ID,App_Date,App_Date_Returned)
VALUES

(5,10,23,'2010-03-15','2010-04-23'),
(7,15,45,'2017-08-12','2017-09-15'),
(9,11,89,'2011-03-06','2011-03-12'),
(21,14,56,'2020-03-15','2020-03-20'),
(19,10,76,'2022-03-15','2022-04-12');

SELECT App_ID, Pat_Fname,Pat_Lname,Pat_ID,App_Date,App_Date_Returned
FROM Appointment 
INNER JOIN PRESCRIPTION on PRESCRIPTION.Pr_ID = Appointment.Pr_ID 
INNER JOIN PAT on PAT.Pat_ID = Appointment.Pat_ID;



--<ADD / INSERT>;
--ALTER PROCEDURE [dbo].[Sp_#AddDataInPatient]
--(
--@Option nvarchar (30),
--@Pat_Fname nvarchar (50),
--@Pat_Lname nvarchar (50),
--@Pat_Add int = NULL, 
--@Pat_tele int = NULL,
--@Pat_email nvarchar(100) = NULL,
--@Pat_Occ nvarchar(100) = NULL,
--@App_Date date = NULL,
--@Pat_MedDetails nvarchar(50)
--)

--AS
--BEGIN	
--		If @Option = 'Add'
--		BEGIN
--		INSERT INTO PAT VALUES (@Pat_Fname, @Pat_Lname, @Pat_Add, @Pat_tele, @Pat_email, @Pat_Occ, @App_Date,@Pat_MedDetails)
--		End

--End

--EXEC Sp_AddDataInPatient
--@Option = 'Add',
-- @Pat_Fname = 'JAKE',
-- @Pat_Lname = 'Black',
-- @Pat_Add = 10,
-- @App_Date = '2012-01-01'

--<DELETE>
--CREATE PROCEDURE Sp_DeleteAddressData
--(
--@ID int = 0
--)
--AS
--BEGIN
--	delete from AD_DRESS where Ad_ID = @id
--END

--Exec  Sp_DeleteAddressData 25
--Select * From AD_DRESS

--<UPDATE>

--CREATE  PROCEDURE [dbo].[Sp_UpdateDataInPatient]
--(
--@Option nvarchar (30),
--@id tinyint,
--@Pat_Fname nvarchar (50),
--@Pat_Lname nvarchar (50),
--@Pat_Add int, 
--@Pat_tele int,
--@Pat_email nvarchar(100),
--@Pat_Occ nvarchar(100),
--@App_Date date,
--@Pat_MedDetails nvarchar(100)
--)

--AS
--BEGIN	

--	If @Option = 'Update Name'
--	BEGIN
--	update PAT Set 
--	Pat_Fname = @Pat_Fname,
--	Pat_Lname = @Pat_Lname
--	WHERE Pat_ID = @ID
--	END	

--	If @Option = 'Update Address'
--	BEGIN
--	update Pat Set 
--	Pat_Add = @Pat_Add
--	WHERE Pat_ID = @ID
--	END	

--	If @Option = 'Update tele'
--	BEGIN
--	update PAT Set 
--	Pat_tele = @Pat_tele
--	WHERE Pat_ID = @ID
--	END	

--	If @Option = 'Update Email'
--	BEGIN
--	update PAT Set 
--	Pat_email = @pat_email
--	WHERE Pat_ID = @ID
--	END	
--If @Option = 'Update Patient Details'
--	BEGIN
--	update PAT Set 
--	Pat_MedDetails = @Pat_MedDetails
--	WHERE Pat_ID = @ID
--	END	
--End

--Exec  [dbo].[Sp_UpdateDataInPatient]
--@Option = 'Update Name',
--@id = 28,
--@Pat_Fname = 'KIM', 
--@Pat_Lname = 'FRYDAY',
--@Pat_Add = NULL,
--@Pat_tele = NULL,
--@Pat_email = NULL,
--@Pat_Occ = NULL,
--@App_Date = NULL,
--@Pat_MedDeatils = Null

--Select * From Pat

--<FIND>
--CREATE PROCEDURE sp_FindDoctor (@FinDoc_ID int , @FinDoc_Name varchar (100)Output)
	
	
--AS
--BEGIN
--	SELECT @FinDoc_Name =Doc_Fname +' '+Doc_Lname
--		FROM Doctor


--END

--Declare @FinDoc_Name varchar(100)
--		Exec sp_FindDoctor 2,@FinDoc_Name out
--		print @FinDoc_Name


------scalar-valued functions ----------

--Create Function Appointment2000s()
--returns int as
--Begin
--	declare @AppointmentCount as int;
--	Select @AppointmentCount = Count(App_year)
--	from Appointment
--	where App_year >= 2000;
--	return @AppointmentCount;
--end;
--select dbo.Appointment2000s();


--Create Function Newpatientafter2007()
--returns int as
--Begin
--	declare @Persons as int;
--	Select @Persons = Count(App_Date)
--	from PAT
--	where App_Date >= '2007-01-01' and App_Date < '2013-01-01';
--	return @Persons;
--end;
--select dbo.Newpatientafter2007();


-----inline table-valued functions ------

--Create Function NewPatAfter2007(@App_Date date)
--returns table
--as
--	return Select  *
--	from PAT
--	where Pat_Date >= '2007-01-01' and Pat_Date < '2013-01-01';
--go
--SELECT *
--FROM NewPatAfter2007 ('ALFKI')

--Create Function App_Date_Returned(@App_Date_Returned date)
--returns table
--as
--	return Select  *
--	from Appointment
--	where App_Date_Returned >= '2000-01-01' 
--go

--Drop function App_Date_Returned

--SELECT *
--FROM App_Date_Returned ('ALFKI')


--- multi-statement table-valued functions ---

--CREATE FUNCTION dbo.GetPatientByOccupation (@Pat_Occ nvarchar(100)
--RETURNS @Patient TABLE (Pat_ID tinyint, Pat_Fname nvarchar(30), Pat_Lname nvarchar(30)))
--AS
--BEGIN
--   INSERT INTO @Patient
--   SELECT Pat_ID, Pat_Fname, Pat_Lname
--   FROM PAT
--   WHERE Pat_Occ = @Pat_Occ,

--   RETURN
--END


--DECLARE @occupation nvarchar(100) = 'Student'
--DECLARE @Patient TABLE (Pat_ID tinyint, Pat_Fname nvarchar(30), Pat_Lname nvarchar(30))

--INSERT INTO @Patient
--SELECT *
--FROM dbo.GetPatientByOccupation(@Pat_Occ)

--SELECT * FROM @Patient


--------Trigger----
--CREATE TRIGGER update_patient_address
--ON Pat
--AFTER UPDATE
--AS
--BEGIN
--   UPDATE PAT
--   SET Pat_Add = (SELECT Ad_ID FROM AD_DRESS WHERE AD_DRESS.Ad_ID = updated.Ad_ID)
--   FROM UPDATE
--   WHERE EXISTS (SELECT * FROM UPDATE WHERE PAT.Pat_ID = updated.Pat_ID)
--END


